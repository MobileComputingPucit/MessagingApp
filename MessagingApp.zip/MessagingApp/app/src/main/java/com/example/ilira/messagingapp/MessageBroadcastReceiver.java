package com.example.ilira.messagingapp;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.telephony.SmsMessage;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Objects;

/**
 * Created by ilira on 1/27/2018.
 */
public class MessageBroadcastReceiver extends BroadcastReceiver
{
    public static  final  String SMS_Bundle = "pdus" ;


    @Override
    public void onReceive(Context context, Intent intent) {
        Bundle intentExtras = intent.getExtras();

        if (intentExtras != null )
        {
            Object[] message = (Objects[]) intentExtras.get(SMS_Bundle);
            String smsMessageStr = " " ;

            for (int i = 0 ; i < message.length ; i++)
            {
                SmsMessage smsMessage = SmsMessage.createFromPdu((byte[]) message[i]) ;

                String smsBody = smsMessage.getMessageBody().toString();
                String address = smsMessage.getOriginatingAddress();
                long timeMillis = smsMessage.getTimestampMillis();

                Date date = new Date(timeMillis);
                SimpleDateFormat format = new SimpleDateFormat("dd/mm/yy");
                String dateText = format.format(date);

                smsMessageStr += address + "at" + "\t" + dateText + "\n" ;
                smsMessageStr += smsBody + "\n" ;
            }

            Toast.makeText(context, smsMessageStr,Toast.LENGTH_SHORT).show() ;

            ReceivingMessageActivity inst = ReceivingMessageActivity.instance();
            if (inst != null )
            {
                inst.updateList(smsMessageStr);
            }
        }
    }
}
