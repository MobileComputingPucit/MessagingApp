package com.example.ilira.messagingapp;


import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import static android.widget.Toast.LENGTH_LONG;

public class SendMessageActivity extends Activity {

    Button sendSmsbtn ;
    EditText toMobileNumber ;
    EditText smsMessageET ;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_send_message);

        sendSmsbtn = (Button) findViewById(R.id.btnSendMessage) ;
        toMobileNumber = (EditText) findViewById(R.id.editTextMobileNumber);
        smsMessageET = (EditText) findViewById(R.id.editTextMessage) ;

        sendSmsbtn.setOnClickListener(new View.OnClickListener()
        {

            @Override
            public void onClick(View v) {
                sendMessage() ;

            }
        })
        ;
    }

    private  void sendMessage()
    {
        String toMobile = toMobileNumber.getText().toString();
        String smsMessage = smsMessageET.getText().toString();

        try
        {
            SmsManager smsManager = SmsManager.getDefault();
            smsManager.sendTextMessage(toMobile,null,smsMessage,null,null);

            final Toast toast = Toast.makeText(this, "Message Sent", LENGTH_LONG );

        }
        catch (Exception e )
        {
            e.printStackTrace();

        }
    }

    public  void  goToInbox(View v)
    {
        Intent intent = new Intent(SendMessageActivity.this, ReceivingMessageActivity.class);
        startActivity(intent);
    }

}
